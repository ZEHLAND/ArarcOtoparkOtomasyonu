﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtoparkOtomasyonu
{
    public partial class Frm : Form
    {
        public Frm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BP5JE1Q;Initial Catalog=AracOtopark;Integrated Security=True");
        DataSet dset = new DataSet();
        private void Frm_Load(object sender, EventArgs e)
        {
            SatislariListele();
            Hesapla();
        }

        private void Hesapla()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select sum(Tutar) from Satis", con);
            label1.Text = "Toplam Tutar : " + komut.ExecuteScalar() + " lira";
        }

        private void SatislariListele()
        {
            con.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Satis", con);
            adtr.Fill(dset, "Satis");
            dataGridView1.DataSource = dset.Tables["Satis"];
            con.Close();
        }
    }
}
