﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtoparkOtomasyonu
{
    public partial class frmSeri : Form
    {
        public frmSeri()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BP5JE1Q;Initial Catalog=AracOtopark;Integrated Security=True");
        private void frmSeri_Load(object sender, EventArgs e)
        {
            Marka();
        }

        private void Marka()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from MarkaBilgileri ", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboMarka.Items.Add(read["Marka"].ToString());

            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand komut = new SqlCommand("insert into SeriBilgileri(Seri,Marka) values('"+textSeri.Text+"','" + comboMarka.Text + "')", con);
            komut.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Markaya Bağlı Araç Seri Eklendi. ");
            textSeri.Clear();
            comboMarka.Text = "";
            
        }
    }
}
