﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtoparkOtomasyonu
{
    public partial class Form1 : Form
    {
        public Form1(EventHandler btnSatis_Click_1)
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmOtoparkKaydı kayit = new frmOtoparkKaydı();
            kayit.ShowDialog();
        }

        private void OtoparkYerleri_Click(object sender, EventArgs e)
        {
            frmOtoparkYerleri yer = new frmOtoparkYerleri();
            yer.ShowDialog();
        }

        private void OtoparkCıkısSayfası_Click(object sender, EventArgs e)
        {
            frmOtoparkCıkıs cıkıs = new frmOtoparkCıkıs();
            cıkıs.ShowDialog();
        }

        private void Cıkış_Click(object sender, EventArgs e)
        {
            Application.Exit();  
        }

        private void BtnSatis_Click_1(object sender, EventArgs e)
        {

            Frm satis = new Frm();
            satis.ShowDialog();
        }

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
    }
}
