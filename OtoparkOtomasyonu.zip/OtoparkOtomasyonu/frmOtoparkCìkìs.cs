﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtoparkOtomasyonu
{
    public partial class frmOtoparkCıkıs : Form
    {
        public frmOtoparkCıkıs()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BP5JE1Q;Initial Catalog=AracOtopark;Integrated Security=True");
        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void groupUcret_Enter(object sender, EventArgs e)
        {

        }

        private void frmOtoparkCıkıs_Load(object sender, EventArgs e)
        {
            DoluYerler();
            Plakalar();
            timer1.Enabled = true;
        }

        private void Plakalar()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from AracOtoparkKaydı ", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboPlakaAra1.Items.Add(read["Plaka"].ToString());
            }
            con.Close();
        }

        private void DoluYerler()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from AracDurumu where durum = 'Dolu'",con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboParkYeri.Items.Add(read["parkyeri"].ToString());
            }
            con.Close();
        }

        private void comboPlakaAra1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from AracOtoparkKaydı where Plaka= '"+comboPlakaAra1.SelectedItem+"' ", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                textPlakaYeri1.Text = read["parkyeri"].ToString();
            }
            con.Close();
        }

        private void comboParkYeri_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from AracOtoparkKaydı where ParkYeri= '" + comboParkYeri.SelectedItem + "' ", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                textParkYeri.Text = read["ParkYeri"].ToString();
                textTc.Text = read["TC"].ToString();
                textAd.Text = read["Ad"].ToString();
                textSoyad.Text = read["Soyad"].ToString();
                textMarka.Text = read["Marka"].ToString();
                textSeri.Text = read["Seri"].ToString();
                textPlaka.Text = read["Plaka"].ToString();
                lblGelisTarihi.Text = read["Tarih"].ToString();
            }
            con.Close();
            DateTime gelis,cıkıs;
            gelis = DateTime.Parse(lblGelisTarihi.Text);
            cıkıs = DateTime.Parse(llblCıkısTarihi.Text);
            TimeSpan fark = cıkıs - gelis;
            lblSure.Text = fark.TotalHours.ToString("0.00");
            lblToplamTutar.Text = ((double.Parse(lblSure.Text)) * (0.75)).ToString("0.00")+" lira";
            


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            llblCıkısTarihi.Text = DateTime.Now.ToString();
            
        }

        private void cıkıs_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand komut = new SqlCommand("delete from AracOtoparkKaydı where Plaka='" + textPlaka.Text + "'", con);
            komut.ExecuteNonQuery();
            SqlCommand komut2 = new SqlCommand("update AracDurumu set durum='Boş'where ParkYeri='" + textParkYeri.Text + "'", con);
            komut.ExecuteNonQuery();
            SqlCommand komut3 = new SqlCommand("insert into Satis(ParkYeri,Plaka,GelisTarihi,CıkısTarihi,Sure,Tutar) values(@ParkYeri,@Plaka,@GelisTarihi,@CıkısTarihi,@Sure,@Tutar)", con);
            komut3.Parameters.AddWithValue("@ParkYeri", textParkYeri.Text);
            komut3.Parameters.AddWithValue("@Plaka", textPlaka.Text);
            komut3.Parameters.AddWithValue("@GelisTarihi", lblGelisTarihi.Text);
            komut3.Parameters.AddWithValue("@CıkısTarihi", llblCıkısTarihi.Text);
            komut3.Parameters.AddWithValue("@Sure", double.Parse(lblSure.Text));
            komut3.Parameters.AddWithValue("@Tutar", double.Parse(lblToplamTutar.Text));
            komut3.ExecuteNonQuery();
            
            con.Close();
            MessageBox.Show("Arac Cıkışı Yapıldı.");
            foreach (Control item in groupAracBilgi.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                    textParkYeri.Text = "";
                    comboParkYeri.Text = "";
                    textPlaka.Text = "";
                    llblCıkısTarihi.Text = "";
                
                }
            }
        
            comboPlakaAra1.Items.Clear();
            comboParkYeri.Items.Clear();
            DoluYerler();
            Plakalar();
        }

        private void iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }
    }
}
