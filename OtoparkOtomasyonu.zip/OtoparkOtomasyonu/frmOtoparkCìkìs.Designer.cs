﻿
namespace OtoparkOtomasyonu
{
    partial class frmOtoparkCıkıs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboPlakaAra1 = new System.Windows.Forms.ComboBox();
            this.textPlakaYeri1 = new System.Windows.Forms.TextBox();
            this.textParkYeri = new System.Windows.Forms.TextBox();
            this.comboParkYeri = new System.Windows.Forms.ComboBox();
            this.textTc = new System.Windows.Forms.TextBox();
            this.textAd = new System.Windows.Forms.TextBox();
            this.textSoyad = new System.Windows.Forms.TextBox();
            this.textMarka = new System.Windows.Forms.TextBox();
            this.textPlaka = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupParkBilgisi = new System.Windows.Forms.GroupBox();
            this.groupAracBilgi = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textSeri = new System.Windows.Forms.TextBox();
            this.cıkıs = new System.Windows.Forms.Button();
            this.iptal = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblGelisTarihi = new System.Windows.Forms.Label();
            this.llblCıkısTarihi = new System.Windows.Forms.Label();
            this.lblSure = new System.Windows.Forms.Label();
            this.lblToplamTutar = new System.Windows.Forms.Label();
            this.groupUcret = new System.Windows.Forms.GroupBox();
            this.groupParkBilgisi.SuspendLayout();
            this.groupAracBilgi.SuspendLayout();
            this.groupUcret.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboPlakaAra1
            // 
            this.comboPlakaAra1.FormattingEnabled = true;
            this.comboPlakaAra1.Location = new System.Drawing.Point(94, 33);
            this.comboPlakaAra1.Name = "comboPlakaAra1";
            this.comboPlakaAra1.Size = new System.Drawing.Size(121, 29);
            this.comboPlakaAra1.TabIndex = 0;
            this.comboPlakaAra1.SelectedIndexChanged += new System.EventHandler(this.comboPlakaAra1_SelectedIndexChanged);
            // 
            // textPlakaYeri1
            // 
            this.textPlakaYeri1.Location = new System.Drawing.Point(94, 72);
            this.textPlakaYeri1.Name = "textPlakaYeri1";
            this.textPlakaYeri1.Size = new System.Drawing.Size(121, 28);
            this.textPlakaYeri1.TabIndex = 1;
            // 
            // textParkYeri
            // 
            this.textParkYeri.Location = new System.Drawing.Point(350, 24);
            this.textParkYeri.Name = "textParkYeri";
            this.textParkYeri.Size = new System.Drawing.Size(121, 28);
            this.textParkYeri.TabIndex = 3;
            this.textParkYeri.Text = " ";
            // 
            // comboParkYeri
            // 
            this.comboParkYeri.FormattingEnabled = true;
            this.comboParkYeri.Location = new System.Drawing.Point(110, 24);
            this.comboParkYeri.Name = "comboParkYeri";
            this.comboParkYeri.Size = new System.Drawing.Size(121, 29);
            this.comboParkYeri.TabIndex = 2;
            this.comboParkYeri.SelectedIndexChanged += new System.EventHandler(this.comboParkYeri_SelectedIndexChanged);
            // 
            // textTc
            // 
            this.textTc.Location = new System.Drawing.Point(352, 148);
            this.textTc.Name = "textTc";
            this.textTc.Size = new System.Drawing.Size(121, 28);
            this.textTc.TabIndex = 4;
            // 
            // textAd
            // 
            this.textAd.Location = new System.Drawing.Point(352, 72);
            this.textAd.Name = "textAd";
            this.textAd.Size = new System.Drawing.Size(121, 28);
            this.textAd.TabIndex = 5;
            // 
            // textSoyad
            // 
            this.textSoyad.Location = new System.Drawing.Point(352, 111);
            this.textSoyad.Name = "textSoyad";
            this.textSoyad.Size = new System.Drawing.Size(121, 28);
            this.textSoyad.TabIndex = 6;
            // 
            // textMarka
            // 
            this.textMarka.Location = new System.Drawing.Point(109, 79);
            this.textMarka.Name = "textMarka";
            this.textMarka.Size = new System.Drawing.Size(121, 28);
            this.textMarka.TabIndex = 7;
            // 
            // textPlaka
            // 
            this.textPlaka.Location = new System.Drawing.Point(110, 152);
            this.textPlaka.Name = "textPlaka";
            this.textPlaka.Size = new System.Drawing.Size(121, 28);
            this.textPlaka.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "PlakaAra";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 21);
            this.label2.TabIndex = 10;
            this.label2.Text = "Park Yeri";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 21);
            this.label3.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(258, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 21);
            this.label4.TabIndex = 12;
            this.label4.Text = "Park Yeri :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(309, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 21);
            this.label5.TabIndex = 13;
            this.label5.Text = "TC :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(309, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 21);
            this.label6.TabIndex = 14;
            this.label6.Text = "AD :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(274, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 21);
            this.label7.TabIndex = 15;
            this.label7.Text = "SOYAD :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 21);
            this.label8.TabIndex = 16;
            this.label8.Text = "MARKA:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(47, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 21);
            this.label9.TabIndex = 17;
            this.label9.Text = "Plaka:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 21);
            this.label10.TabIndex = 18;
            this.label10.Text = "Park Yeri :";
            // 
            // groupParkBilgisi
            // 
            this.groupParkBilgisi.Controls.Add(this.comboPlakaAra1);
            this.groupParkBilgisi.Controls.Add(this.textPlakaYeri1);
            this.groupParkBilgisi.Controls.Add(this.label1);
            this.groupParkBilgisi.Controls.Add(this.label2);
            this.groupParkBilgisi.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupParkBilgisi.Location = new System.Drawing.Point(12, 12);
            this.groupParkBilgisi.Name = "groupParkBilgisi";
            this.groupParkBilgisi.Size = new System.Drawing.Size(231, 131);
            this.groupParkBilgisi.TabIndex = 19;
            this.groupParkBilgisi.TabStop = false;
            this.groupParkBilgisi.Text = "ParkBilgileri";
            // 
            // groupAracBilgi
            // 
            this.groupAracBilgi.Controls.Add(this.label11);
            this.groupAracBilgi.Controls.Add(this.textSeri);
            this.groupAracBilgi.Controls.Add(this.comboParkYeri);
            this.groupAracBilgi.Controls.Add(this.textParkYeri);
            this.groupAracBilgi.Controls.Add(this.label10);
            this.groupAracBilgi.Controls.Add(this.textTc);
            this.groupAracBilgi.Controls.Add(this.label9);
            this.groupAracBilgi.Controls.Add(this.textAd);
            this.groupAracBilgi.Controls.Add(this.label8);
            this.groupAracBilgi.Controls.Add(this.textSoyad);
            this.groupAracBilgi.Controls.Add(this.label7);
            this.groupAracBilgi.Controls.Add(this.textMarka);
            this.groupAracBilgi.Controls.Add(this.label6);
            this.groupAracBilgi.Controls.Add(this.textPlaka);
            this.groupAracBilgi.Controls.Add(this.label5);
            this.groupAracBilgi.Controls.Add(this.label3);
            this.groupAracBilgi.Controls.Add(this.label4);
            this.groupAracBilgi.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupAracBilgi.Location = new System.Drawing.Point(12, 159);
            this.groupAracBilgi.Name = "groupAracBilgi";
            this.groupAracBilgi.Size = new System.Drawing.Size(539, 208);
            this.groupAracBilgi.TabIndex = 20;
            this.groupAracBilgi.TabStop = false;
            this.groupAracBilgi.Text = "Arac Bilgileri";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 21);
            this.label11.TabIndex = 20;
            this.label11.Text = "SERİ:";
            // 
            // textSeri
            // 
            this.textSeri.Location = new System.Drawing.Point(109, 118);
            this.textSeri.Name = "textSeri";
            this.textSeri.Size = new System.Drawing.Size(121, 28);
            this.textSeri.TabIndex = 19;
            // 
            // cıkıs
            // 
            this.cıkıs.BackColor = System.Drawing.Color.Black;
            this.cıkıs.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cıkıs.ForeColor = System.Drawing.Color.Red;
            this.cıkıs.Location = new System.Drawing.Point(298, 382);
            this.cıkıs.Name = "cıkıs";
            this.cıkıs.Size = new System.Drawing.Size(105, 31);
            this.cıkıs.TabIndex = 22;
            this.cıkıs.Text = "CIKIŞ";
            this.cıkıs.UseVisualStyleBackColor = false;
            this.cıkıs.Click += new System.EventHandler(this.cıkıs_Click);
            // 
            // iptal
            // 
            this.iptal.BackColor = System.Drawing.Color.Black;
            this.iptal.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iptal.ForeColor = System.Drawing.Color.Red;
            this.iptal.Location = new System.Drawing.Point(409, 382);
            this.iptal.Name = "iptal";
            this.iptal.Size = new System.Drawing.Size(102, 31);
            this.iptal.TabIndex = 23;
            this.iptal.Text = "İPTAL";
            this.iptal.UseVisualStyleBackColor = false;
            this.iptal.Click += new System.EventHandler(this.iptal_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(52, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 21);
            this.label12.TabIndex = 10;
            this.label12.Text = "Cıkış Tarihi :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(54, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 21);
            this.label13.TabIndex = 11;
            this.label13.Text = "Giriş Tarihi :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(104, 72);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 21);
            this.label14.TabIndex = 12;
            this.label14.Text = "Süre :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 93);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(116, 21);
            this.label15.TabIndex = 13;
            this.label15.Text = "ToplamTutar :";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // lblGelisTarihi
            // 
            this.lblGelisTarihi.AutoSize = true;
            this.lblGelisTarihi.ForeColor = System.Drawing.Color.Red;
            this.lblGelisTarihi.Location = new System.Drawing.Point(165, 27);
            this.lblGelisTarihi.Name = "lblGelisTarihi";
            this.lblGelisTarihi.Size = new System.Drawing.Size(28, 21);
            this.lblGelisTarihi.TabIndex = 14;
            this.lblGelisTarihi.Text = "---";
            // 
            // llblCıkısTarihi
            // 
            this.llblCıkısTarihi.AutoSize = true;
            this.llblCıkısTarihi.ForeColor = System.Drawing.Color.Red;
            this.llblCıkısTarihi.Location = new System.Drawing.Point(165, 51);
            this.llblCıkısTarihi.Name = "llblCıkısTarihi";
            this.llblCıkısTarihi.Size = new System.Drawing.Size(28, 21);
            this.llblCıkısTarihi.TabIndex = 14;
            this.llblCıkısTarihi.Text = "---";
            // 
            // lblSure
            // 
            this.lblSure.AutoSize = true;
            this.lblSure.ForeColor = System.Drawing.Color.Red;
            this.lblSure.Location = new System.Drawing.Point(165, 72);
            this.lblSure.Name = "lblSure";
            this.lblSure.Size = new System.Drawing.Size(28, 21);
            this.lblSure.TabIndex = 14;
            this.lblSure.Text = "---";
            // 
            // lblToplamTutar
            // 
            this.lblToplamTutar.AutoSize = true;
            this.lblToplamTutar.ForeColor = System.Drawing.Color.Red;
            this.lblToplamTutar.Location = new System.Drawing.Point(165, 93);
            this.lblToplamTutar.Name = "lblToplamTutar";
            this.lblToplamTutar.Size = new System.Drawing.Size(28, 21);
            this.lblToplamTutar.TabIndex = 14;
            this.lblToplamTutar.Text = "---";
            // 
            // groupUcret
            // 
            this.groupUcret.BackColor = System.Drawing.Color.Goldenrod;
            this.groupUcret.Controls.Add(this.lblToplamTutar);
            this.groupUcret.Controls.Add(this.lblSure);
            this.groupUcret.Controls.Add(this.llblCıkısTarihi);
            this.groupUcret.Controls.Add(this.lblGelisTarihi);
            this.groupUcret.Controls.Add(this.label15);
            this.groupUcret.Controls.Add(this.label14);
            this.groupUcret.Controls.Add(this.label13);
            this.groupUcret.Controls.Add(this.label12);
            this.groupUcret.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupUcret.Location = new System.Drawing.Point(254, 12);
            this.groupUcret.Name = "groupUcret";
            this.groupUcret.Size = new System.Drawing.Size(310, 131);
            this.groupUcret.TabIndex = 21;
            this.groupUcret.TabStop = false;
            this.groupUcret.Text = "Ücretlendirme";
            this.groupUcret.Enter += new System.EventHandler(this.groupUcret_Enter);
            // 
            // frmOtoparkCıkıs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(586, 425);
            this.Controls.Add(this.iptal);
            this.Controls.Add(this.cıkıs);
            this.Controls.Add(this.groupUcret);
            this.Controls.Add(this.groupAracBilgi);
            this.Controls.Add(this.groupParkBilgisi);
            this.Name = "frmOtoparkCıkıs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmOtoparkCıkısSayfas";
            this.Load += new System.EventHandler(this.frmOtoparkCıkıs_Load);
            this.groupParkBilgisi.ResumeLayout(false);
            this.groupParkBilgisi.PerformLayout();
            this.groupAracBilgi.ResumeLayout(false);
            this.groupAracBilgi.PerformLayout();
            this.groupUcret.ResumeLayout(false);
            this.groupUcret.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboPlakaAra1;
        private System.Windows.Forms.TextBox textPlakaYeri1;
        private System.Windows.Forms.TextBox textParkYeri;
        private System.Windows.Forms.ComboBox comboParkYeri;
        private System.Windows.Forms.TextBox textTc;
        private System.Windows.Forms.TextBox textAd;
        private System.Windows.Forms.TextBox textSoyad;
        private System.Windows.Forms.TextBox textMarka;
        private System.Windows.Forms.TextBox textPlaka;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupParkBilgisi;
        private System.Windows.Forms.GroupBox groupAracBilgi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textSeri;
        private System.Windows.Forms.Button cıkıs;
        private System.Windows.Forms.Button iptal;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblGelisTarihi;
        private System.Windows.Forms.Label llblCıkısTarihi;
        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.Label lblToplamTutar;
        private System.Windows.Forms.GroupBox groupUcret;
    }
}