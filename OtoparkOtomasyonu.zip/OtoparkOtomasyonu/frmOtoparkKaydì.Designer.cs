﻿
namespace OtoparkOtomasyonu
{
    partial class frmOtoparkKaydı
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textPlaka = new System.Windows.Forms.TextBox();
            this.comboMarka = new System.Windows.Forms.ComboBox();
            this.comboSeri = new System.Windows.Forms.ComboBox();
            this.comboParkYeri = new System.Windows.Forms.ComboBox();
            this.grupKisi = new System.Windows.Forms.GroupBox();
            this.textMail = new System.Windows.Forms.TextBox();
            this.textTel = new System.Windows.Forms.TextBox();
            this.textSoyad = new System.Windows.Forms.TextBox();
            this.textAd = new System.Windows.Forms.TextBox();
            this.textTC = new System.Windows.Forms.TextBox();
            this.Mail = new System.Windows.Forms.Label();
            this.Telefon = new System.Windows.Forms.Label();
            this.Soyad = new System.Windows.Forms.Label();
            this.Ad = new System.Windows.Forms.Label();
            this.TC = new System.Windows.Forms.Label();
            this.grupArac = new System.Windows.Forms.GroupBox();
            this.BtnEkleSeri = new System.Windows.Forms.Button();
            this.BtnEkleMarka = new System.Windows.Forms.Button();
            this.textRenk = new System.Windows.Forms.TextBox();
            this.ParkYeri = new System.Windows.Forms.Label();
            this.Renk = new System.Windows.Forms.Label();
            this.Seri = new System.Windows.Forms.Label();
            this.Marka = new System.Windows.Forms.Label();
            this.Plaka = new System.Windows.Forms.Label();
            this.Kayit = new System.Windows.Forms.Button();
            this.iptal = new System.Windows.Forms.Button();
            this.grupKisi.SuspendLayout();
            this.grupArac.SuspendLayout();
            this.SuspendLayout();
            // 
            // textPlaka
            // 
            this.textPlaka.Location = new System.Drawing.Point(118, 44);
            this.textPlaka.Name = "textPlaka";
            this.textPlaka.Size = new System.Drawing.Size(136, 28);
            this.textPlaka.TabIndex = 5;
            // 
            // comboMarka
            // 
            this.comboMarka.FormattingEnabled = true;
            this.comboMarka.Location = new System.Drawing.Point(118, 82);
            this.comboMarka.Name = "comboMarka";
            this.comboMarka.Size = new System.Drawing.Size(136, 29);
            this.comboMarka.TabIndex = 10;
            this.comboMarka.SelectedIndexChanged += new System.EventHandler(this.comboMarka_SelectedIndexChanged);
            // 
            // comboSeri
            // 
            this.comboSeri.FormattingEnabled = true;
            this.comboSeri.Location = new System.Drawing.Point(118, 122);
            this.comboSeri.Name = "comboSeri";
            this.comboSeri.Size = new System.Drawing.Size(136, 29);
            this.comboSeri.TabIndex = 11;
            this.comboSeri.SelectedIndexChanged += new System.EventHandler(this.comboSeri_SelectedIndexChanged);
            // 
            // comboParkYeri
            // 
            this.comboParkYeri.FormattingEnabled = true;
            this.comboParkYeri.Location = new System.Drawing.Point(118, 200);
            this.comboParkYeri.Name = "comboParkYeri";
            this.comboParkYeri.Size = new System.Drawing.Size(136, 29);
            this.comboParkYeri.TabIndex = 12;
            // 
            // grupKisi
            // 
            this.grupKisi.Controls.Add(this.textMail);
            this.grupKisi.Controls.Add(this.textTel);
            this.grupKisi.Controls.Add(this.textSoyad);
            this.grupKisi.Controls.Add(this.textAd);
            this.grupKisi.Controls.Add(this.textTC);
            this.grupKisi.Controls.Add(this.Mail);
            this.grupKisi.Controls.Add(this.Telefon);
            this.grupKisi.Controls.Add(this.Soyad);
            this.grupKisi.Controls.Add(this.Ad);
            this.grupKisi.Controls.Add(this.TC);
            this.grupKisi.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grupKisi.Location = new System.Drawing.Point(12, 23);
            this.grupKisi.Name = "grupKisi";
            this.grupKisi.Size = new System.Drawing.Size(237, 278);
            this.grupKisi.TabIndex = 13;
            this.grupKisi.TabStop = false;
            this.grupKisi.Text = "Kişi Bilgileri";
            // 
            // textMail
            // 
            this.textMail.Location = new System.Drawing.Point(94, 211);
            this.textMail.Name = "textMail";
            this.textMail.Size = new System.Drawing.Size(124, 28);
            this.textMail.TabIndex = 14;
            // 
            // textTel
            // 
            this.textTel.Location = new System.Drawing.Point(94, 174);
            this.textTel.Name = "textTel";
            this.textTel.Size = new System.Drawing.Size(124, 28);
            this.textTel.TabIndex = 13;
            // 
            // textSoyad
            // 
            this.textSoyad.Location = new System.Drawing.Point(94, 115);
            this.textSoyad.Name = "textSoyad";
            this.textSoyad.Size = new System.Drawing.Size(125, 28);
            this.textSoyad.TabIndex = 12;
            // 
            // textAd
            // 
            this.textAd.Location = new System.Drawing.Point(94, 82);
            this.textAd.Name = "textAd";
            this.textAd.Size = new System.Drawing.Size(125, 28);
            this.textAd.TabIndex = 11;
            // 
            // textTC
            // 
            this.textTC.Location = new System.Drawing.Point(94, 44);
            this.textTC.Name = "textTC";
            this.textTC.Size = new System.Drawing.Size(124, 28);
            this.textTC.TabIndex = 10;
            // 
            // Mail
            // 
            this.Mail.AutoSize = true;
            this.Mail.Location = new System.Drawing.Point(25, 218);
            this.Mail.Name = "Mail";
            this.Mail.Size = new System.Drawing.Size(63, 21);
            this.Mail.TabIndex = 9;
            this.Mail.Text = "e-Mail:";
            // 
            // Telefon
            // 
            this.Telefon.AutoSize = true;
            this.Telefon.Location = new System.Drawing.Point(6, 177);
            this.Telefon.Name = "Telefon";
            this.Telefon.Size = new System.Drawing.Size(82, 21);
            this.Telefon.TabIndex = 8;
            this.Telefon.Text = "TELEFON:";
            // 
            // Soyad
            // 
            this.Soyad.AutoSize = true;
            this.Soyad.Location = new System.Drawing.Point(20, 119);
            this.Soyad.Name = "Soyad";
            this.Soyad.Size = new System.Drawing.Size(68, 21);
            this.Soyad.TabIndex = 7;
            this.Soyad.Text = "SOYAD:";
            // 
            // Ad
            // 
            this.Ad.AutoSize = true;
            this.Ad.Location = new System.Drawing.Point(51, 85);
            this.Ad.Name = "Ad";
            this.Ad.Size = new System.Drawing.Size(37, 21);
            this.Ad.TabIndex = 6;
            this.Ad.Text = "AD:";
            // 
            // TC
            // 
            this.TC.AutoSize = true;
            this.TC.Location = new System.Drawing.Point(55, 47);
            this.TC.Name = "TC";
            this.TC.Size = new System.Drawing.Size(33, 21);
            this.TC.TabIndex = 5;
            this.TC.Text = "TC:";
            // 
            // grupArac
            // 
            this.grupArac.Controls.Add(this.BtnEkleSeri);
            this.grupArac.Controls.Add(this.BtnEkleMarka);
            this.grupArac.Controls.Add(this.textRenk);
            this.grupArac.Controls.Add(this.ParkYeri);
            this.grupArac.Controls.Add(this.Renk);
            this.grupArac.Controls.Add(this.Seri);
            this.grupArac.Controls.Add(this.Marka);
            this.grupArac.Controls.Add(this.Plaka);
            this.grupArac.Controls.Add(this.comboMarka);
            this.grupArac.Controls.Add(this.textPlaka);
            this.grupArac.Controls.Add(this.comboParkYeri);
            this.grupArac.Controls.Add(this.comboSeri);
            this.grupArac.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grupArac.Location = new System.Drawing.Point(268, 23);
            this.grupArac.Name = "grupArac";
            this.grupArac.Size = new System.Drawing.Size(320, 278);
            this.grupArac.TabIndex = 14;
            this.grupArac.TabStop = false;
            this.grupArac.Text = "Arac Bilgileri";
            this.grupArac.Enter += new System.EventHandler(this.grupArac_Enter);
            // 
            // BtnEkleSeri
            // 
            this.BtnEkleSeri.BackColor = System.Drawing.Color.Red;
            this.BtnEkleSeri.Location = new System.Drawing.Point(260, 122);
            this.BtnEkleSeri.Name = "BtnEkleSeri";
            this.BtnEkleSeri.Size = new System.Drawing.Size(32, 26);
            this.BtnEkleSeri.TabIndex = 20;
            this.BtnEkleSeri.Text = "+";
            this.BtnEkleSeri.UseVisualStyleBackColor = false;
            this.BtnEkleSeri.Click += new System.EventHandler(this.BtnEkleSeri_Click);
            // 
            // BtnEkleMarka
            // 
            this.BtnEkleMarka.BackColor = System.Drawing.Color.Red;
            this.BtnEkleMarka.Location = new System.Drawing.Point(260, 79);
            this.BtnEkleMarka.Name = "BtnEkleMarka";
            this.BtnEkleMarka.Size = new System.Drawing.Size(32, 27);
            this.BtnEkleMarka.TabIndex = 19;
            this.BtnEkleMarka.Text = "+";
            this.BtnEkleMarka.UseVisualStyleBackColor = false;
            this.BtnEkleMarka.Click += new System.EventHandler(this.BtnEkleMarka_Click);
            // 
            // textRenk
            // 
            this.textRenk.Location = new System.Drawing.Point(118, 161);
            this.textRenk.Name = "textRenk";
            this.textRenk.Size = new System.Drawing.Size(136, 28);
            this.textRenk.TabIndex = 18;
            // 
            // ParkYeri
            // 
            this.ParkYeri.AutoSize = true;
            this.ParkYeri.Location = new System.Drawing.Point(18, 203);
            this.ParkYeri.Name = "ParkYeri";
            this.ParkYeri.Size = new System.Drawing.Size(94, 21);
            this.ParkYeri.TabIndex = 17;
            this.ParkYeri.Text = "PARK YERİ:";
            // 
            // Renk
            // 
            this.Renk.AutoSize = true;
            this.Renk.Location = new System.Drawing.Point(56, 164);
            this.Renk.Name = "Renk";
            this.Renk.Size = new System.Drawing.Size(56, 21);
            this.Renk.TabIndex = 16;
            this.Renk.Text = "RENK:";
            // 
            // Seri
            // 
            this.Seri.AutoSize = true;
            this.Seri.Location = new System.Drawing.Point(64, 125);
            this.Seri.Name = "Seri";
            this.Seri.Size = new System.Drawing.Size(48, 21);
            this.Seri.TabIndex = 15;
            this.Seri.Text = "SERİ:";
            // 
            // Marka
            // 
            this.Marka.AutoSize = true;
            this.Marka.Location = new System.Drawing.Point(41, 88);
            this.Marka.Name = "Marka";
            this.Marka.Size = new System.Drawing.Size(71, 21);
            this.Marka.TabIndex = 14;
            this.Marka.Text = "MARKA:";
            // 
            // Plaka
            // 
            this.Plaka.AutoSize = true;
            this.Plaka.Location = new System.Drawing.Point(48, 47);
            this.Plaka.Name = "Plaka";
            this.Plaka.Size = new System.Drawing.Size(64, 21);
            this.Plaka.TabIndex = 13;
            this.Plaka.Text = "PLAKA:";
            // 
            // Kayit
            // 
            this.Kayit.BackColor = System.Drawing.Color.Black;
            this.Kayit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kayit.ForeColor = System.Drawing.Color.Red;
            this.Kayit.Location = new System.Drawing.Point(336, 316);
            this.Kayit.Name = "Kayit";
            this.Kayit.Size = new System.Drawing.Size(104, 30);
            this.Kayit.TabIndex = 10;
            this.Kayit.Text = "KAYIT";
            this.Kayit.UseVisualStyleBackColor = false;
            this.Kayit.Click += new System.EventHandler(this.Kayit_Click);
            // 
            // iptal
            // 
            this.iptal.BackColor = System.Drawing.Color.Black;
            this.iptal.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iptal.ForeColor = System.Drawing.Color.Red;
            this.iptal.Location = new System.Drawing.Point(456, 316);
            this.iptal.Name = "iptal";
            this.iptal.Size = new System.Drawing.Size(104, 30);
            this.iptal.TabIndex = 18;
            this.iptal.Text = "İPTAL";
            this.iptal.UseVisualStyleBackColor = false;
            this.iptal.Click += new System.EventHandler(this.iptal_Click);
            // 
            // frmOtoparkKaydı
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(600, 362);
            this.Controls.Add(this.iptal);
            this.Controls.Add(this.Kayit);
            this.Controls.Add(this.grupArac);
            this.Controls.Add(this.grupKisi);
            this.Name = "frmOtoparkKaydı";
            this.Text = "Arac Otopark Kaydı";
            this.Load += new System.EventHandler(this.frmOtoparkKaydı_Load);
            this.grupKisi.ResumeLayout(false);
            this.grupKisi.PerformLayout();
            this.grupArac.ResumeLayout(false);
            this.grupArac.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textPlaka;
        private System.Windows.Forms.ComboBox comboMarka;
        private System.Windows.Forms.ComboBox comboSeri;
        private System.Windows.Forms.ComboBox comboParkYeri;
        private System.Windows.Forms.GroupBox grupKisi;
        private System.Windows.Forms.TextBox textMail;
        private System.Windows.Forms.TextBox textTel;
        private System.Windows.Forms.TextBox textSoyad;
        private System.Windows.Forms.TextBox textAd;
        private System.Windows.Forms.TextBox textTC;
        private System.Windows.Forms.Label Mail;
        private System.Windows.Forms.Label Telefon;
        private System.Windows.Forms.Label Soyad;
        private System.Windows.Forms.Label Ad;
        private System.Windows.Forms.Label TC;
        private System.Windows.Forms.GroupBox grupArac;
        private System.Windows.Forms.TextBox textRenk;
        private System.Windows.Forms.Label ParkYeri;
        private System.Windows.Forms.Label Renk;
        private System.Windows.Forms.Label Seri;
        private System.Windows.Forms.Label Marka;
        private System.Windows.Forms.Label Plaka;
        private System.Windows.Forms.Button Kayit;
        private System.Windows.Forms.Button iptal;
        private System.Windows.Forms.Button BtnEkleSeri;
        private System.Windows.Forms.Button BtnEkleMarka;
    }
}