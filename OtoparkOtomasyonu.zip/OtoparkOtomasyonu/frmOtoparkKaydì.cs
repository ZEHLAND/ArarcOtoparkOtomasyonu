﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OtoparkOtomasyonu
{
    public partial class frmOtoparkKaydı : Form
    {
        public frmOtoparkKaydı()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BP5JE1Q;Initial Catalog=AracOtopark;Integrated Security=True");
        private void frmOtoparkKaydı_Load(object sender, EventArgs e)
        {
            BoşAraçlar();
            MARKA();
           
        }

        private void MARKA()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from MarkaBilgileri ", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboMarka.Items.Add(read["Marka"].ToString());

            }
            con.Close();
        }

        private void BoşAraçlar()
        {
            con.Open();
            SqlCommand komut = new SqlCommand("select *from AracDurumu WHERE durum = 'Boş'", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboParkYeri.Items.Add(read["parkyeri"].ToString());

            }
            con.Close();
        }

        private void iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Kayit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand komut = new SqlCommand("insert into AracOtoParkKaydı(TC,Ad,Soyad,Telefon,Email,Plaka,Marka,Seri,Renk,ParkYeri,Tarih) values(@TC,@Ad,@Soyad,@Telefon,@Email,@Plaka,@Marka,@Seri,@Renk,@ParkYeri,@Tarih)", con);
            komut.Parameters.AddWithValue("@TC", textTC.Text);
            komut.Parameters.AddWithValue("@Ad", textAd.Text);
            komut.Parameters.AddWithValue("@Soyad", textSoyad.Text);
            komut.Parameters.AddWithValue("@Telefon", textTel.Text);
            komut.Parameters.AddWithValue("@Email", textMail.Text);
            komut.Parameters.AddWithValue("@Plaka", textPlaka.Text);
            komut.Parameters.AddWithValue("@Marka", comboMarka.Text);
            komut.Parameters.AddWithValue("@Seri", comboSeri.Text);
            komut.Parameters.AddWithValue("@Renk", textRenk.Text);
            komut.Parameters.AddWithValue("@ParkYeri", comboParkYeri.Text);
            komut.Parameters.AddWithValue("@Tarih", DateTime.Now.ToString());
            
            komut.ExecuteNonQuery();
            
            SqlCommand komut2 = new SqlCommand("update AracDurumu set durum = 'Dolu' where parkyeri='"+comboParkYeri.SelectedItem+"'",con);
            komut2.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Arac kaydı oluşturuldu.","kayıt");
            comboParkYeri.Items.Clear();

            BoşAraçlar();
            comboMarka.Items.Clear();
            MARKA();
            comboSeri.Items.Clear();

            foreach (Control item in grupKisi.Controls)
            {
                if (item is TextBox)

                {
                    item.Text = "";
                }
                if (item is ComboBox)

                {
                    item.Text = "";
                }
            }
            foreach (Control item in grupArac.Controls)
            {
                if (item is ComboBox)

                {
                    item.Text = "";
                }
                if (item is TextBox)

                {
                    item.Text = "";
                }
            }
        }

        private void BtnEkleMarka_Click(object sender, EventArgs e)
        {
            frmMarka marka = new frmMarka();
            marka.ShowDialog();
        }

        private void BtnEkleSeri_Click(object sender, EventArgs e)
        {
            frmSeri seri = new frmSeri();
            seri.ShowDialog();
        }

        private void comboMarka_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboSeri.Items.Clear();
            con.Open();
            SqlCommand komut = new SqlCommand("select Marka,Seri from SeriBilgileri where Marka='"+comboMarka.SelectedItem+"'", con);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboSeri.Items.Add(read["Seri"].ToString());

            }
            con.Close();

        }

        private void comboSeri_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void grupArac_Enter(object sender, EventArgs e)
        {

        }
    }
}
